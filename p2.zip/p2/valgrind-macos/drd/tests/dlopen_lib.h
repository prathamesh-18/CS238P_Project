extern void foo();
